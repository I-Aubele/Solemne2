from django.db import models

# Create your models here.

class Vendedores(models.Model):
    Id_Vendedor=models.AutoField(primary_key=True)
    Nombre_Completo=models.CharField(max_length=35, null=False, blank=False)
    Fecha_Nacimiento=models.DateField()

    def Nombre_Completo(self):
        cadena="{0} --- {1} --- {2}"
        return cadena.format(self.Id_Vendedor, self.Nombre_Completo, self.Fecha_Nacimiento)

    def __str__(self):
        return self.Vendedor()

class Ventas(models.Model):
    Id_Venta=models.AutoField(primary_key=True)
    Fecha=models.DateField()
    Comentario=models.TextField(null=False, blank=False)

    def __str__(self):
        return "{0} --- {1} --- {2}".format(self.Id_Venta, self.Fecha, self.Comentario)

class Productos(models.Model):
    Id_Producto=models.AutoField(primary_key=True)
    Nombre_Producto=models.CharField(max_length=35, null=False, blank=False)
    Unidades=models.IntegerField(null=False, blank=False)

    def __str__(self):
        return "{0} --- {1} --- {2}".format(self.Id_Producto, self.Nombre_Producto,self.Unidades)

class Productos_Ventas(models.Model):
    Ventas=models.ForeignKey(Ventas, null=False, blank=False, on_delete=models.CASCADE)
    Productos=models.ForeignKey(Productos, null=False, blank=False, on_delete=models.CASCADE)
    Cantidades=models.IntegerField(null=False, blank=False)

    def __str__(self):
        return "{0} --- {1} --- {2}".format(self.Ventas, self.Productos, self.Cantidades)
