from django.contrib import admin
from Solemne2.Apps.GestionVentas.models import *

# Register your models here.

admin.site.register(Vendedores)
admin.site.register(Ventas)
admin.site.register(Productos)
admin.site.register(Productos_Ventas)
