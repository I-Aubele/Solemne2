from django.apps import AppConfig


class GestionventasConfig(AppConfig):
    name = 'GestionVentas'
